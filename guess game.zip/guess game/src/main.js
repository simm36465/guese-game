jQuery(document).ready(function ($) {
  var myGuess = Math.floor(Math.random() * 20) + 1;

  var attemps = 1;
  var score = 0;
  $("#start").on("click", function () {
    $("#NumAttemp").text(attemps + " attemps");
    $("#score").text(" points");
    $("#board").hide();
    $(".start").show();
  });
  $(".check").on("click", function () {
    if ($("#attemp").val() == "") {
      alert("type number's guessing ");
    } else {
      attemps++;
      if (myGuess < $("#attemp").val()) {
        $(".indice").text("Lower");
      }
      if (myGuess > $("#attemp").val()) {
        $(".indice").text("Higher");
      }
      if (myGuess == $("#attemp").val()) {
        score++;
        $("#score").text(score + " points");
        $(".indice").text("Well done! You got it in " + attemps + " attemps");
        myGuess = Math.floor(Math.random() * 20) + 1;
      }
      $(".res").show();
      $(".start").hide();
      $(".try").on("click", function () {
        $(".res").hide();
        $(".start").show();
        $("#NumAttemp").text(attemps + " attemps");
        $("#attemp").val("");
      })
    }
  });
});


// while (guess !== myGuess) {
//   guess = parseInt(prompt("What number am I thinking of?"), 10);
//   guesses++;
//   if (guess < myGuess) {
//     alert("Higher.");
//   } else if (guess > myGuess) {
//     alert("Lower.");
//   }
// }

// alert(`Well done! You got it in ${ guesses }!`);